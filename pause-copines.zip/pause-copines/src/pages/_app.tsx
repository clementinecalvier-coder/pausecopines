import type { AppProps } from 'next/app';
import Head from 'next/head';
import '../styles/globals.css';

export default function App({ Component, pageProps }: AppProps) {
  return (
    <>
      <Head>
        <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
        <meta name="theme-color" content="#b91c1c" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="Pause Copines" />
        <link rel="manifest" href="/manifest.json" />
        <link rel="apple-touch-icon" href="/icon-192.png" />
        <title>Pause Copines — Trouve tes copines parisiennes ✨</title>
        <meta name="description" content="Des événements pour les filles à Paris. Rejoins la communauté Pause Copines et fais de nouvelles copines qui te ressemblent." />
        <meta property="og:title" content="Pause Copines" />
        <meta property="og:description" content="Des événements pour les filles à Paris 💕" />
        <meta property="og:type" content="website" />
      </Head>
      <Component {...pageProps} />
    </>
  );
}
