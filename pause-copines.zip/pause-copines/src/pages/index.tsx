import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';

const EVENTS = [
  {
    emoji: '🍷',
    title: 'Wine & Vibes',
    desc: 'Dégustation de vins naturels + rencontres',
    date: 'Sam 3 mai · 19h',
    lieu: 'Oberkampf',
    spots: 12,
  },
  {
    emoji: '🎨',
    title: 'Atelier Céramique',
    desc: 'Crée ton bol en argile entre copines',
    date: 'Dim 11 mai · 14h',
    lieu: 'Le Marais',
    spots: 8,
  },
  {
    emoji: '🧘',
    title: 'Morning Yoga & Brunch',
    desc: 'Yoga doux + brunch healthy ensoleillé',
    date: 'Sam 17 mai · 10h',
    lieu: 'Canal Saint-Martin',
    spots: 15,
  },
  {
    emoji: '📚',
    title: 'Book Club Féministe',
    desc: 'Discussion autour d\'un livre fort',
    date: 'Jeu 22 mai · 19h30',
    lieu: 'Montmartre',
    spots: 10,
  },
  {
    emoji: '🎭',
    title: 'Impro & Cocktails',
    desc: 'Cours d\'impro débutant + afterwork',
    date: 'Ven 30 mai · 18h',
    lieu: 'Bastille',
    spots: 20,
  },
  {
    emoji: '🌿',
    title: 'Pique-nique Botanique',
    desc: 'Pique-nique au Jardin des Plantes',
    date: 'Dim 8 juin · 13h',
    lieu: '5ème',
    spots: 25,
  },
];

export default function Home() {
  const [visible, setVisible] = useState(false);
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setVisible(true);
  }, []);

  return (
    <div className="min-h-dvh" style={{ background: 'var(--rose-blush)' }}>
      {/* Nav */}
      <nav
        className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-4"
        style={{
          background: 'rgba(253, 240, 240, 0.85)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          borderBottom: '1px solid rgba(245, 198, 198, 0.3)',
        }}
      >
        <div className="flex items-center gap-1">
          <span
            className="font-display text-xl font-bold"
            style={{ color: 'var(--bordeaux)' }}
          >
            PAUSE
          </span>
          <span
            className="font-script text-2xl"
            style={{ color: 'var(--bordeaux)', lineHeight: 1 }}
          >
            Copines.
          </span>
        </div>
        <Link href="/inscription">
          <button className="btn-primary" style={{ padding: '10px 24px', fontSize: '13px' }}>
            Rejoindre ✨
          </button>
        </Link>
      </nav>

      {/* Hero */}
      <section
        ref={heroRef}
        className="relative flex flex-col items-center justify-center text-center px-6 pt-32 pb-20 overflow-hidden"
        style={{ minHeight: '100dvh' }}
      >
        {/* Decorative blobs */}
        <div
          style={{
            position: 'absolute',
            top: '10%',
            right: '-5%',
            width: '300px',
            height: '300px',
            borderRadius: '60% 40% 70% 30% / 50% 60% 40% 50%',
            background: 'rgba(245, 198, 198, 0.4)',
            filter: 'blur(40px)',
            animation: 'float 8s ease-in-out infinite',
          }}
        />
        <div
          style={{
            position: 'absolute',
            bottom: '15%',
            left: '-8%',
            width: '250px',
            height: '250px',
            borderRadius: '40% 60% 30% 70% / 60% 40% 60% 40%',
            background: 'rgba(229, 62, 62, 0.08)',
            filter: 'blur(50px)',
            animation: 'float 10s ease-in-out infinite reverse',
          }}
        />

        <div className={`stagger-child ${visible ? 'animate-fade-up' : ''}`}>
          <span
            className="font-body text-base tracking-widest uppercase"
            style={{ color: 'var(--bordeaux-light)', letterSpacing: '0.2em' }}
          >
            Paris · 25–35 ans
          </span>
        </div>

        <h1
          className={`stagger-child font-display mt-4 ${visible ? 'animate-fade-up delay-200' : ''}`}
          style={{
            fontSize: 'clamp(48px, 10vw, 90px)',
            lineHeight: 1.05,
            color: 'var(--bordeaux-dark)',
            fontWeight: 900,
            maxWidth: '700px',
          }}
        >
          Trouve tes
          <br />
          <em style={{ color: 'var(--bordeaux)', fontStyle: 'italic' }}>nouvelles</em>
          <br />
          copines 💕
        </h1>

        <p
          className={`stagger-child font-body mt-6 ${visible ? 'animate-fade-up delay-300' : ''}`}
          style={{
            fontSize: 'clamp(17px, 3vw, 22px)',
            color: '#8B3A3A',
            maxWidth: '500px',
            lineHeight: 1.7,
            fontWeight: 300,
            fontStyle: 'italic',
          }}
        >
          Des événements pensés pour les Parisiennes qui veulent sortir de leurs cercles habituels
          et créer de vraies connexions.
        </p>

        <div
          className={`stagger-child flex flex-col sm:flex-row gap-4 mt-10 ${visible ? 'animate-fade-up delay-400' : ''}`}
        >
          <Link href="/inscription">
            <button
              className="btn-primary"
              style={{ fontSize: '16px', padding: '16px 40px' }}
            >
              Je m&apos;inscris 🌸
            </button>
          </Link>
          <a href="#events">
            <button
              style={{
                background: 'transparent',
                border: '1.5px solid var(--bordeaux)',
                color: 'var(--bordeaux)',
                padding: '16px 40px',
                borderRadius: '50px',
                fontSize: '16px',
                fontFamily: 'DM Sans, sans-serif',
                fontWeight: 500,
                cursor: 'pointer',
                transition: 'all 200ms cubic-bezier(0.23, 1, 0.32, 1)',
              }}
              onMouseEnter={(e) => {
                (e.target as HTMLElement).style.background = 'var(--bordeaux)';
                (e.target as HTMLElement).style.color = 'white';
              }}
              onMouseLeave={(e) => {
                (e.target as HTMLElement).style.background = 'transparent';
                (e.target as HTMLElement).style.color = 'var(--bordeaux)';
              }}
            >
              Voir les events ✨
            </button>
          </a>
        </div>

        {/* Social proof */}
        <div
          className={`stagger-child mt-14 flex items-center gap-3 ${visible ? 'animate-fade-up delay-500' : ''}`}
        >
          <div className="flex -space-x-2">
            {['#f8a4a4', '#e07878', '#c94040', '#a02020'].map((c, i) => (
              <div
                key={i}
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: '50%',
                  background: c,
                  border: '2px solid white',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '14px',
                }}
              >
                {['😊', '🌸', '✨', '💕'][i]}
              </div>
            ))}
          </div>
          <span
            className="font-body"
            style={{ color: '#8B3A3A', fontSize: '15px', fontStyle: 'italic' }}
          >
            +240 Parisiennes nous ont déjà rejointes
          </span>
        </div>
      </section>

      {/* Events section */}
      <section id="events" className="px-6 pb-24">
        <div style={{ maxWidth: '900px', margin: '0 auto' }}>
          <div className="text-center mb-12">
            <h2
              className="font-display"
              style={{
                fontSize: 'clamp(36px, 6vw, 56px)',
                color: 'var(--bordeaux-dark)',
                fontWeight: 700,
              }}
            >
              Les prochains
              <br />
              <span
                className="font-script"
                style={{ color: 'var(--bordeaux)', fontSize: '110%' }}
              >
                événements
              </span>
            </h2>
            <p
              className="font-body mt-3"
              style={{ color: '#8B3A3A', fontSize: '17px', fontStyle: 'italic' }}
            >
              Petits groupes · Ambiance chaleureuse · Vraies rencontres
            </p>
          </div>

          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(270px, 1fr))',
              gap: '20px',
            }}
          >
            {EVENTS.map((event, i) => (
              <EventCard key={i} event={event} index={i} />
            ))}
          </div>

          <div className="text-center mt-14">
            <Link href="/inscription">
              <button
                className="btn-primary"
                style={{ fontSize: '16px', padding: '18px 48px' }}
              >
                Rejoindre la communauté 🌸
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* Why section */}
      <section
        className="px-6 py-24"
        style={{ background: 'white', borderTop: '1px solid rgba(245, 198, 198, 0.4)' }}
      >
        <div style={{ maxWidth: '700px', margin: '0 auto', textAlign: 'center' }}>
          <h2
            className="font-display"
            style={{ fontSize: 'clamp(32px, 5vw, 48px)', color: 'var(--bordeaux-dark)', fontWeight: 700 }}
          >
            Pourquoi{' '}
            <span className="font-script" style={{ color: 'var(--bordeaux)', fontSize: '110%' }}>
              Pause Copines ?
            </span>
          </h2>
          <p
            className="font-body mt-5"
            style={{ fontSize: '18px', lineHeight: 1.8, color: '#8B3A3A', fontWeight: 300, fontStyle: 'italic' }}
          >
            Parce qu&apos;après 25 ans à Paris, se faire de vraies copines devient un peu plus
            compliqué. On sort des études, les cercles se ferment... mais l&apos;envie de
            rencontres authentiques, elle, reste bien là.
          </p>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(3, 1fr)',
              gap: '24px',
              marginTop: '48px',
            }}
          >
            {[
              { icon: '🎯', title: 'Ciblé', desc: 'Des femmes qui te ressemblent, même tranche d\'âge, mêmes envies' },
              { icon: '✨', title: 'Qualitatif', desc: 'Petits groupes pour de vraies conversations, pas du networking' },
              { icon: '🌸', title: 'Safe', desc: 'Un espace bienveillant et sans prise de tête' },
            ].map((item, i) => (
              <div
                key={i}
                style={{
                  background: 'var(--rose-blush)',
                  borderRadius: '20px',
                  padding: '24px 16px',
                  border: '1px solid rgba(245, 198, 198, 0.4)',
                }}
              >
                <div style={{ fontSize: '32px', marginBottom: '12px' }}>{item.icon}</div>
                <div
                  className="font-display"
                  style={{ fontSize: '18px', fontWeight: 700, color: 'var(--bordeaux-dark)', marginBottom: '8px' }}
                >
                  {item.title}
                </div>
                <div
                  className="font-body"
                  style={{ fontSize: '14px', color: '#8B3A3A', lineHeight: 1.6 }}
                >
                  {item.desc}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer
        className="text-center py-10 px-6"
        style={{ borderTop: '1px solid rgba(245, 198, 198, 0.4)' }}
      >
        <div className="flex items-center justify-center gap-1 mb-3">
          <span className="font-display font-bold" style={{ color: 'var(--bordeaux)' }}>
            PAUSE
          </span>
          <span className="font-script text-2xl" style={{ color: 'var(--bordeaux)' }}>
            Copines.
          </span>
        </div>
        <p className="font-body" style={{ color: '#c9a0a0', fontSize: '13px', fontStyle: 'italic' }}>
          Paris · 2025 · Fait avec 💕
        </p>
      </footer>
    </div>
  );
}

function EventCard({ event, index }: { event: typeof EVENTS[0]; index: number }) {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      className="card"
      style={{
        cursor: 'pointer',
        transform: hovered ? 'translateY(-4px)' : 'translateY(0)',
        boxShadow: hovered
          ? '0 20px 50px rgba(185, 28, 28, 0.12)'
          : '0 4px 30px rgba(185, 28, 28, 0.06)',
        transition: 'transform 250ms cubic-bezier(0.23, 1, 0.32, 1), box-shadow 250ms cubic-bezier(0.23, 1, 0.32, 1)',
        animationDelay: `${index * 80}ms`,
        opacity: 0,
        animation: 'fadeUp 0.6s cubic-bezier(0.23, 1, 0.32, 1) forwards',
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div style={{ fontSize: '36px', marginBottom: '12px' }}>{event.emoji}</div>
      <h3
        className="font-display"
        style={{ fontSize: '20px', fontWeight: 700, color: 'var(--bordeaux-dark)', marginBottom: '6px' }}
      >
        {event.title}
      </h3>
      <p
        className="font-body"
        style={{ fontSize: '14px', color: '#8B3A3A', lineHeight: 1.5, marginBottom: '16px', fontStyle: 'italic' }}
      >
        {event.desc}
      </p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
        <span style={{ fontSize: '12px', color: 'var(--bordeaux)', fontWeight: 500 }}>
          📅 {event.date}
        </span>
        <span style={{ fontSize: '12px', color: 'var(--bordeaux)', fontWeight: 500 }}>
          📍 {event.lieu}
        </span>
        <span style={{ fontSize: '12px', color: '#c9a0a0' }}>
          {event.spots} places disponibles
        </span>
      </div>
      <Link href="/inscription">
        <button
          className="btn-primary"
          style={{ width: '100%', marginTop: '16px', padding: '12px', fontSize: '14px' }}
        >
          Je veux y aller →
        </button>
      </Link>
    </div>
  );
}
