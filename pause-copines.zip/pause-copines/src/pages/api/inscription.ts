import type { NextApiRequest, NextApiResponse } from 'next';

// Storage abstraction - works with Vercel KV or falls back to in-memory
let inMemoryStore: Record<string, any>[] = [];

async function saveToKV(data: any) {
  try {
    // Try Vercel KV if available
    if (process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN) {
      const { kv } = await import('@vercel/kv');
      const id = `member:${Date.now()}-${Math.random().toString(36).slice(2)}`;
      await kv.set(id, JSON.stringify({ ...data, id }));
      // Also keep a list of IDs
      const existing = await kv.get<string[]>('members:list') || [];
      await kv.set('members:list', [...existing, id]);
      return { ok: true };
    }
  } catch (err) {
    console.log('KV not available, using memory store');
  }
  // Fallback: in-memory (for development)
  const id = `member-${Date.now()}`;
  inMemoryStore.push({ ...data, id });
  return { ok: true };
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { email, prenom } = req.body;

  if (!email || !prenom) {
    return res.status(400).json({ error: 'Email et prénom requis' });
  }

  // Basic email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ error: 'Email invalide' });
  }

  try {
    await saveToKV(req.body);
    return res.status(200).json({ success: true, message: 'Inscription enregistrée !' });
  } catch (error) {
    console.error('Error saving inscription:', error);
    return res.status(500).json({ error: 'Erreur serveur' });
  }
}

// Export memory store for admin endpoint (dev only)
export { inMemoryStore };
