import type { NextApiRequest, NextApiResponse } from 'next';

const ADMIN_TOKEN = process.env.ADMIN_SECRET || 'pausecopines2025';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Check auth
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ') || auth.slice(7) !== ADMIN_TOKEN) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    // Try Vercel KV
    if (process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN) {
      const { kv } = await import('@vercel/kv');
      const ids = await kv.get<string[]>('members:list') || [];
      const members = await Promise.all(
        ids.map(async (id) => {
          const raw = await kv.get<string>(id);
          return raw ? JSON.parse(raw) : null;
        })
      );
      return res.status(200).json({
        members: members.filter(Boolean).sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        ),
      });
    }

    // Fallback: return mock data for development
    const mockMembers = [
      {
        id: 'mock-1',
        prenom: 'Sofia',
        email: 'sofia@example.com',
        instagram: 'sofia.paris',
        age: '28',
        quartier: 'Le Marais',
        interets: ['🍷 Vins & cocktails', '🎨 Art & créativité', '📚 Livres & culture'],
        envies: ['💬 Des conversations profondes', '🥂 Des sorties fun et légères'],
        vibe: '🌸 Douce & bienveillante',
        frequence: '2-3 fois par mois',
        message: "J'adore l'idée de rencontrer des femmes qui me ressemblent !",
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      },
      {
        id: 'mock-2',
        prenom: 'Jade',
        email: 'jade@example.com',
        age: '31',
        quartier: 'Bastille',
        interets: ['🎵 Musique & concerts', '🎭 Théâtre & spectacles', '✈️ Voyages'],
        envies: ['🎉 Des nouvelles aventures', '🌍 Découvrir Paris autrement'],
        vibe: '⚡ Spontanée & aventurière',
        frequence: '1 fois par semaine',
        createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
      },
      {
        id: 'mock-3',
        prenom: 'Luna',
        email: 'luna@example.com',
        instagram: 'luna_copines',
        age: '26',
        quartier: 'Montmartre',
        interets: ['🌿 Nature & outdoor', '🧘 Bien-être & yoga', '🍽️ Gastronomie'],
        envies: ['☕ Des rencontres régulières et routinières', '💬 Des conversations profondes'],
        vibe: '🌊 Zen & équilibrée',
        frequence: '1 fois par mois',
        createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
      },
    ];

    return res.status(200).json({ members: mockMembers });
  } catch (error) {
    console.error('Error fetching members:', error);
    return res.status(500).json({ error: 'Erreur serveur' });
  }
}
