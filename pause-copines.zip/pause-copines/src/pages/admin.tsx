import { useState, useEffect } from 'react';
import Link from 'next/link';

type Member = {
  id: string;
  prenom: string;
  email: string;
  instagram?: string;
  age: string;
  quartier?: string;
  interets: string[];
  envies: string[];
  vibe: string;
  frequence: string;
  message?: string;
  createdAt: string;
};

export default function Admin() {
  const [authed, setAuthed] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<Member | null>(null);

  const login = () => {
    if (password === process.env.NEXT_PUBLIC_ADMIN_PASSWORD || password === 'pausecopines2025') {
      setAuthed(true);
      setError('');
      fetchMembers();
    } else {
      setError('Mot de passe incorrect');
      setPassword('');
    }
  };

  const fetchMembers = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/members', {
        headers: { Authorization: `Bearer pausecopines2025` },
      });
      if (res.ok) {
        const data = await res.json();
        setMembers(data.members || []);
      }
    } catch {
      console.error('Erreur chargement membres');
    } finally {
      setLoading(false);
    }
  };

  const filtered = members.filter(
    (m) =>
      m.prenom?.toLowerCase().includes(search.toLowerCase()) ||
      m.email?.toLowerCase().includes(search.toLowerCase()) ||
      m.quartier?.toLowerCase().includes(search.toLowerCase())
  );

  if (!authed) {
    return (
      <div
        style={{
          minHeight: '100dvh',
          background: 'var(--rose-blush)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '24px',
        }}
      >
        <div
          className="card"
          style={{ width: '100%', maxWidth: '400px', animation: 'fadeUp 0.5s cubic-bezier(0.23, 1, 0.32, 1) forwards' }}
        >
          <div className="text-center" style={{ marginBottom: '28px' }}>
            <div style={{ fontSize: '40px', marginBottom: '12px' }}>🔐</div>
            <h1
              className="font-display"
              style={{ fontSize: '28px', fontWeight: 700, color: 'var(--bordeaux-dark)' }}
            >
              Admin
            </h1>
            <p
              className="font-script"
              style={{ color: 'var(--bordeaux)', fontSize: '22px' }}
            >
              Pause Copines.
            </p>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <input
              className="input-base"
              type="password"
              placeholder="Mot de passe admin"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && login()}
            />
            {error && (
              <p style={{ color: 'var(--bordeaux-light)', fontSize: '13px', fontFamily: 'DM Sans' }}>
                {error}
              </p>
            )}
            <button
              className="btn-primary"
              style={{ fontSize: '15px', padding: '14px' }}
              onClick={login}
            >
              Accéder →
            </button>
          </div>

          <div style={{ marginTop: '20px', textAlign: 'center' }}>
            <Link href="/">
              <span style={{ fontSize: '13px', color: '#c9a0a0', fontFamily: 'DM Sans', cursor: 'pointer', textDecoration: 'underline' }}>
                ← Retour au site
              </span>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100dvh', background: '#f8f0f0' }}>
      {/* Admin header */}
      <div
        style={{
          background: 'var(--bordeaux-dark)',
          padding: '16px 24px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span className="font-display" style={{ color: 'white', fontWeight: 700, fontSize: '18px' }}>
            PAUSE
          </span>
          <span className="font-script" style={{ color: 'rgba(255,255,255,0.8)', fontSize: '22px' }}>
            Copines.
          </span>
          <span
            style={{
              background: 'rgba(255,255,255,0.15)',
              color: 'white',
              fontSize: '11px',
              padding: '3px 10px',
              borderRadius: '20px',
              fontFamily: 'DM Sans',
              letterSpacing: '0.1em',
              textTransform: 'uppercase',
            }}
          >
            Admin
          </span>
        </div>
        <button
          onClick={() => setAuthed(false)}
          style={{
            background: 'rgba(255,255,255,0.1)',
            border: 'none',
            color: 'white',
            padding: '8px 16px',
            borderRadius: '20px',
            fontFamily: 'DM Sans',
            fontSize: '13px',
            cursor: 'pointer',
          }}
        >
          Déconnexion
        </button>
      </div>

      <div style={{ padding: '24px', maxWidth: '1100px', margin: '0 auto' }}>
        {/* Stats */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
            gap: '16px',
            marginBottom: '28px',
          }}
        >
          {[
            { label: 'Membres total', value: members.length, emoji: '👥' },
            { label: 'Cette semaine', value: members.filter((m) => {
              const d = new Date(m.createdAt);
              const now = new Date();
              const diff = (now.getTime() - d.getTime()) / (1000 * 60 * 60 * 24);
              return diff <= 7;
            }).length, emoji: '📈' },
            { label: 'Avec Instagram', value: members.filter((m) => m.instagram).length, emoji: '📸' },
          ].map((stat) => (
            <div
              key={stat.label}
              className="card"
              style={{ padding: '20px', textAlign: 'center' }}
            >
              <div style={{ fontSize: '28px' }}>{stat.emoji}</div>
              <div
                className="font-display"
                style={{ fontSize: '32px', fontWeight: 900, color: 'var(--bordeaux)', lineHeight: 1 }}
              >
                {stat.value}
              </div>
              <div style={{ fontSize: '12px', color: '#c9a0a0', fontFamily: 'DM Sans', marginTop: '4px' }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Search */}
        <div style={{ marginBottom: '16px' }}>
          <input
            className="input-base"
            style={{ maxWidth: '400px' }}
            placeholder="Rechercher par prénom, email, quartier..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        {/* Table */}
        {loading ? (
          <div style={{ textAlign: 'center', padding: '60px', color: '#c9a0a0', fontFamily: 'DM Sans' }}>
            Chargement... 💕
          </div>
        ) : (
          <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid var(--rose-medium)', background: 'var(--rose-blush)' }}>
                    {['Prénom', 'Email', 'Instagram', 'Âge', 'Quartier', 'Vibe', 'Date', 'Actions'].map((h) => (
                      <th
                        key={h}
                        style={{
                          padding: '14px 16px',
                          textAlign: 'left',
                          fontSize: '11px',
                          fontWeight: 600,
                          fontFamily: 'DM Sans',
                          color: '#c9a0a0',
                          textTransform: 'uppercase',
                          letterSpacing: '0.1em',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 ? (
                    <tr>
                      <td
                        colSpan={8}
                        style={{ textAlign: 'center', padding: '48px', color: '#c9a0a0', fontFamily: 'DM Sans', fontStyle: 'italic' }}
                      >
                        Aucun membre pour l&apos;instant...
                      </td>
                    </tr>
                  ) : (
                    filtered.map((m, i) => (
                      <tr
                        key={m.id || i}
                        style={{
                          borderBottom: '1px solid rgba(245, 198, 198, 0.3)',
                          transition: 'background 150ms ease',
                          cursor: 'pointer',
                        }}
                        onMouseEnter={(e) => (e.currentTarget.style.background = 'var(--rose-blush)')}
                        onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}
                        onClick={() => setSelected(m)}
                      >
                        <td style={tdStyle}>{m.prenom}</td>
                        <td style={{ ...tdStyle, color: 'var(--bordeaux)' }}>{m.email}</td>
                        <td style={tdStyle}>{m.instagram ? `@${m.instagram}` : '—'}</td>
                        <td style={tdStyle}>{m.age}</td>
                        <td style={tdStyle}>{m.quartier || '—'}</td>
                        <td style={tdStyle}>{m.vibe || '—'}</td>
                        <td style={{ ...tdStyle, color: '#c9a0a0', fontSize: '12px' }}>
                          {new Date(m.createdAt).toLocaleDateString('fr-FR')}
                        </td>
                        <td style={tdStyle}>
                          <button
                            onClick={(e) => { e.stopPropagation(); setSelected(m); }}
                            style={{
                              fontSize: '12px',
                              padding: '4px 12px',
                              borderRadius: '20px',
                              border: '1px solid var(--bordeaux)',
                              background: 'transparent',
                              color: 'var(--bordeaux)',
                              cursor: 'pointer',
                              fontFamily: 'DM Sans',
                            }}
                          >
                            Voir
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Export hint */}
        <p style={{ fontSize: '12px', color: '#c9a0a0', fontFamily: 'DM Sans', marginTop: '12px', fontStyle: 'italic' }}>
          💡 Les données sont stockées dans Vercel KV. Configure NEXT_PUBLIC_ADMIN_PASSWORD dans les variables d&apos;environnement Vercel.
        </p>
      </div>

      {/* Detail Modal */}
      {selected && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(127, 29, 29, 0.3)',
            backdropFilter: 'blur(8px)',
            display: 'flex',
            alignItems: 'flex-end',
            justifyContent: 'center',
            zIndex: 100,
            padding: '24px',
          }}
          onClick={() => setSelected(null)}
        >
          <div
            className="card"
            style={{
              width: '100%',
              maxWidth: '560px',
              maxHeight: '80vh',
              overflowY: 'auto',
              animation: 'fadeUp 0.3s cubic-bezier(0.32, 0.72, 0, 1) forwards',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
              <div>
                <h2 className="font-display" style={{ fontSize: '24px', fontWeight: 700, color: 'var(--bordeaux-dark)' }}>
                  {selected.prenom}
                </h2>
                <p style={{ fontSize: '13px', color: '#c9a0a0', fontFamily: 'DM Sans' }}>
                  {new Date(selected.createdAt).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}
                </p>
              </div>
              <button
                onClick={() => setSelected(null)}
                style={{ background: 'var(--rose-light)', border: 'none', borderRadius: '50%', width: '36px', height: '36px', cursor: 'pointer', fontSize: '16px' }}
              >
                ✕
              </button>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <DetailRow label="Email" value={selected.email} />
              {selected.instagram && <DetailRow label="Instagram" value={`@${selected.instagram}`} />}
              <DetailRow label="Âge" value={`${selected.age} ans`} />
              {selected.quartier && <DetailRow label="Quartier" value={selected.quartier} />}
              {selected.vibe && <DetailRow label="Vibe" value={selected.vibe} />}
              {selected.frequence && <DetailRow label="Fréquence" value={selected.frequence} />}

              <div style={{ borderTop: '1px solid var(--rose-medium)', paddingTop: '12px' }}>
                <p style={{ fontSize: '11px', fontWeight: 600, color: '#c9a0a0', fontFamily: 'DM Sans', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: '8px' }}>
                  Centres d&apos;intérêt
                </p>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                  {selected.interets?.map((int) => (
                    <span key={int} style={{ fontSize: '12px', background: 'var(--rose-blush)', border: '1px solid var(--rose-medium)', borderRadius: '20px', padding: '4px 10px', color: 'var(--bordeaux)', fontFamily: 'DM Sans' }}>
                      {int}
                    </span>
                  ))}
                </div>
              </div>

              {selected.envies?.length > 0 && (
                <div>
                  <p style={{ fontSize: '11px', fontWeight: 600, color: '#c9a0a0', fontFamily: 'DM Sans', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: '8px' }}>
                    Envies
                  </p>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                    {selected.envies.map((env) => (
                      <span key={env} style={{ fontSize: '12px', background: 'var(--rose-blush)', border: '1px solid var(--rose-medium)', borderRadius: '20px', padding: '4px 10px', color: 'var(--bordeaux)', fontFamily: 'DM Sans' }}>
                        {env}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {selected.message && (
                <div style={{ background: 'var(--rose-blush)', borderRadius: '12px', padding: '14px' }}>
                  <p style={{ fontSize: '11px', fontWeight: 600, color: '#c9a0a0', fontFamily: 'DM Sans', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: '6px' }}>
                    Message
                  </p>
                  <p className="font-body" style={{ fontSize: '14px', color: '#8B3A3A', lineHeight: 1.6, fontStyle: 'italic' }}>
                    &ldquo;{selected.message}&rdquo;
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const tdStyle: React.CSSProperties = {
  padding: '14px 16px',
  fontSize: '14px',
  fontFamily: 'DM Sans',
  color: 'var(--bordeaux-dark)',
  whiteSpace: 'nowrap',
};

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '12px' }}>
      <span style={{ fontSize: '11px', fontWeight: 600, color: '#c9a0a0', fontFamily: 'DM Sans', textTransform: 'uppercase', letterSpacing: '0.1em', flexShrink: 0 }}>
        {label}
      </span>
      <span style={{ fontSize: '14px', color: 'var(--bordeaux-dark)', fontFamily: 'DM Sans' }}>
        {value}
      </span>
    </div>
  );
}
