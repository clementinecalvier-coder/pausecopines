import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';

const INTERETS = [
  '🍷 Vins & cocktails', '🎨 Art & créativité', '🧘 Bien-être & yoga',
  '📚 Livres & culture', '🎭 Théâtre & spectacles', '🍽️ Gastronomie',
  '🎵 Musique & concerts', '🌿 Nature & outdoor', '🎬 Cinéma',
  '💄 Mode & beauté', '🏃 Sport & fitness', '✈️ Voyages',
  '🌱 Écologie & engagement', '💡 Entrepreneuriat', '🎮 Gaming & tech',
];

const ENVIES = [
  '💬 Des conversations profondes',
  '🥂 Des sorties fun et légères',
  '🤝 Un réseau de femmes inspirantes',
  '🎉 Des nouvelles aventures',
  '☕ Des rencontres régulières et routinières',
  '🌍 Découvrir Paris autrement',
];

const VIBES = [
  '🌸 Douce & bienveillante',
  '🔥 Intense & passionnée',
  '😄 Humor & légèreté',
  '🎯 Ambitieuse & focus',
  '🌊 Zen & équilibrée',
  '⚡ Spontanée & aventurière',
];

const FREQUENCES = [
  '1 fois par mois', '2-3 fois par mois', '1 fois par semaine', 'Quand l\'inspiration vient !',
];

type Step = 0 | 1 | 2 | 3 | 4;

export default function Inscription() {
  const router = useRouter();
  const [step, setStep] = useState<Step>(0);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const [form, setForm] = useState({
    prenom: '',
    email: '',
    instagram: '',
    age: '',
    quartier: '',
    interets: [] as string[],
    envies: [] as string[],
    vibe: '',
    frequence: '',
    message: '',
  });

  const toggleArray = (key: 'interets' | 'envies', value: string) => {
    setForm((prev) => ({
      ...prev,
      [key]: prev[key].includes(value)
        ? prev[key].filter((v) => v !== value)
        : [...prev[key], value],
    }));
  };

  const canProceed = () => {
    switch (step) {
      case 0: return form.prenom.trim() && form.email.trim() && form.age;
      case 1: return form.interets.length >= 3;
      case 2: return form.envies.length >= 1;
      case 3: return form.vibe && form.frequence;
      default: return true;
    }
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/inscription', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, createdAt: new Date().toISOString() }),
      });
      if (res.ok) {
        setSuccess(true);
      } else {
        alert('Une erreur est survenue. Réessaie !');
      }
    } catch {
      alert('Erreur réseau. Réessaie !');
    } finally {
      setLoading(false);
    }
  };

  const steps = ['Toi', 'Tes passions', 'Tes envies', 'Ta vibe', 'Récap'];
  const progress = ((step) / 4) * 100;

  if (success) {
    return <SuccessPage prenom={form.prenom} />;
  }

  return (
    <div
      style={{
        minHeight: '100dvh',
        background: 'var(--rose-blush)',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      {/* Header */}
      <div
        style={{
          padding: '20px 24px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          borderBottom: '1px solid rgba(245, 198, 198, 0.3)',
          background: 'rgba(253, 240, 240, 0.8)',
          backdropFilter: 'blur(20px)',
          position: 'sticky',
          top: 0,
          zIndex: 10,
        }}
      >
        <Link href="/">
          <div className="flex items-center gap-1" style={{ cursor: 'pointer' }}>
            <span className="font-display font-bold" style={{ color: 'var(--bordeaux)', fontSize: '18px' }}>
              PAUSE
            </span>
            <span className="font-script" style={{ color: 'var(--bordeaux)', fontSize: '22px' }}>
              Copines.
            </span>
          </div>
        </Link>
        <span
          className="font-body"
          style={{ color: '#c9a0a0', fontSize: '13px', fontStyle: 'italic' }}
        >
          Étape {step + 1} / 5
        </span>
      </div>

      {/* Progress bar */}
      <div style={{ height: '3px', background: 'var(--rose-medium)', position: 'relative' }}>
        <div
          style={{
            position: 'absolute',
            left: 0,
            top: 0,
            height: '100%',
            width: `${progress}%`,
            background: 'var(--bordeaux)',
            transition: 'width 400ms cubic-bezier(0.23, 1, 0.32, 1)',
          }}
        />
      </div>

      {/* Step dots */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'center',
          gap: '8px',
          padding: '16px',
        }}
      >
        {steps.map((s, i) => (
          <div
            key={i}
            style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '4px',
              opacity: i <= step ? 1 : 0.4,
              transition: 'opacity 300ms ease',
            }}
          >
            <div
              style={{
                width: 8,
                height: 8,
                borderRadius: '50%',
                background: i === step ? 'var(--bordeaux)' : i < step ? 'var(--bordeaux-light)' : 'var(--rose-medium)',
                transition: 'background 300ms ease',
              }}
            />
          </div>
        ))}
      </div>

      {/* Form body */}
      <div
        style={{
          flex: 1,
          maxWidth: '560px',
          width: '100%',
          margin: '0 auto',
          padding: '0 20px 40px',
        }}
      >
        <div key={step} style={{ animation: 'fadeUp 0.4s cubic-bezier(0.23, 1, 0.32, 1) forwards' }}>
          {step === 0 && <StepIdentity form={form} setForm={setForm} />}
          {step === 1 && (
            <StepChips
              title="Tes passions 💫"
              subtitle="Choisis au moins 3 centres d'intérêt"
              items={INTERETS}
              selected={form.interets}
              onToggle={(v) => toggleArray('interets', v)}
            />
          )}
          {step === 2 && (
            <StepChips
              title="Ce que tu cherches ✨"
              subtitle="Qu'est-ce qui t'attire dans Pause Copines ?"
              items={ENVIES}
              selected={form.envies}
              onToggle={(v) => toggleArray('envies', v)}
            />
          )}
          {step === 3 && (
            <StepVibe
              form={form}
              setForm={setForm}
              vibes={VIBES}
              frequences={FREQUENCES}
            />
          )}
          {step === 4 && <StepRecap form={form} />}
        </div>

        {/* Navigation */}
        <div
          style={{
            display: 'flex',
            gap: '12px',
            marginTop: '32px',
          }}
        >
          {step > 0 && (
            <button
              onClick={() => setStep((s) => (s - 1) as Step)}
              style={{
                flex: 1,
                padding: '16px',
                borderRadius: '50px',
                border: '1.5px solid var(--bordeaux)',
                background: 'transparent',
                color: 'var(--bordeaux)',
                fontFamily: 'DM Sans, sans-serif',
                fontSize: '15px',
                cursor: 'pointer',
                transition: 'all 200ms cubic-bezier(0.23, 1, 0.32, 1)',
              }}
            >
              ← Retour
            </button>
          )}
          {step < 4 ? (
            <button
              className="btn-primary"
              style={{ flex: 2, fontSize: '15px', padding: '16px', opacity: canProceed() ? 1 : 0.4 }}
              onClick={() => canProceed() && setStep((s) => (s + 1) as Step)}
              disabled={!canProceed()}
            >
              Continuer →
            </button>
          ) : (
            <button
              className="btn-primary"
              style={{ flex: 2, fontSize: '15px', padding: '16px' }}
              onClick={handleSubmit}
              disabled={loading}
            >
              {loading ? '💕 Envoi...' : 'C\'est parti ! 🌸'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function StepIdentity({
  form,
  setForm,
}: {
  form: any;
  setForm: any;
}) {
  return (
    <div>
      <div style={{ marginBottom: '32px' }}>
        <h1
          className="font-display"
          style={{ fontSize: '32px', fontWeight: 700, color: 'var(--bordeaux-dark)', lineHeight: 1.2 }}
        >
          Parle-nous de toi 🌸
        </h1>
        <p
          className="font-body"
          style={{ color: '#8B3A3A', fontSize: '16px', marginTop: '8px', fontStyle: 'italic' }}
        >
          Ces infos restent entre nous, promis !
        </p>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <div>
          <label style={{ display: 'block', fontSize: '13px', fontWeight: 500, color: 'var(--bordeaux-dark)', marginBottom: '8px', letterSpacing: '0.03em' }}>
            Ton prénom *
          </label>
          <input
            className="input-base"
            placeholder="Luna, Sofia, Jade..."
            value={form.prenom}
            onChange={(e) => setForm({ ...form, prenom: e.target.value })}
          />
        </div>

        <div>
          <label style={{ display: 'block', fontSize: '13px', fontWeight: 500, color: 'var(--bordeaux-dark)', marginBottom: '8px', letterSpacing: '0.03em' }}>
            Ton email *
          </label>
          <input
            className="input-base"
            type="email"
            placeholder="ton@email.fr"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
          />
        </div>

        <div>
          <label style={{ display: 'block', fontSize: '13px', fontWeight: 500, color: 'var(--bordeaux-dark)', marginBottom: '8px', letterSpacing: '0.03em' }}>
            Ton Instagram (facultatif)
          </label>
          <div style={{ position: 'relative' }}>
            <span
              style={{
                position: 'absolute',
                left: '18px',
                top: '50%',
                transform: 'translateY(-50%)',
                color: '#c9a0a0',
                fontFamily: 'DM Sans, sans-serif',
                fontSize: '15px',
              }}
            >
              @
            </span>
            <input
              className="input-base"
              style={{ paddingLeft: '36px' }}
              placeholder="tonpseudo"
              value={form.instagram}
              onChange={(e) => setForm({ ...form, instagram: e.target.value })}
            />
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
          <div>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: 500, color: 'var(--bordeaux-dark)', marginBottom: '8px' }}>
              Ton âge *
            </label>
            <select
              className="input-base"
              value={form.age}
              onChange={(e) => setForm({ ...form, age: e.target.value })}
            >
              <option value="">Ton âge...</option>
              {Array.from({ length: 11 }, (_, i) => 25 + i).map((age) => (
                <option key={age} value={age}>
                  {age} ans
                </option>
              ))}
            </select>
          </div>
          <div>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: 500, color: 'var(--bordeaux-dark)', marginBottom: '8px' }}>
              Ton quartier
            </label>
            <input
              className="input-base"
              placeholder="Marais, 10ème..."
              value={form.quartier}
              onChange={(e) => setForm({ ...form, quartier: e.target.value })}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function StepChips({
  title,
  subtitle,
  items,
  selected,
  onToggle,
}: {
  title: string;
  subtitle: string;
  items: string[];
  selected: string[];
  onToggle: (v: string) => void;
}) {
  return (
    <div>
      <div style={{ marginBottom: '32px' }}>
        <h1
          className="font-display"
          style={{ fontSize: '32px', fontWeight: 700, color: 'var(--bordeaux-dark)', lineHeight: 1.2 }}
        >
          {title}
        </h1>
        <p
          className="font-body"
          style={{ color: '#8B3A3A', fontSize: '16px', marginTop: '8px', fontStyle: 'italic' }}
        >
          {subtitle}
        </p>
      </div>

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
        {items.map((item, i) => (
          <button
            key={i}
            className={`chip ${selected.includes(item) ? 'selected' : ''}`}
            onClick={() => onToggle(item)}
            style={{ animationDelay: `${i * 30}ms` }}
          >
            {item}
          </button>
        ))}
      </div>

      {selected.length > 0 && (
        <p
          style={{
            marginTop: '16px',
            fontSize: '13px',
            color: 'var(--bordeaux)',
            fontFamily: 'DM Sans, sans-serif',
          }}
        >
          {selected.length} sélectionné{selected.length > 1 ? 's' : ''} 💕
        </p>
      )}
    </div>
  );
}

function StepVibe({
  form,
  setForm,
  vibes,
  frequences,
}: {
  form: any;
  setForm: any;
  vibes: string[];
  frequences: string[];
}) {
  return (
    <div>
      <div style={{ marginBottom: '32px' }}>
        <h1
          className="font-display"
          style={{ fontSize: '32px', fontWeight: 700, color: 'var(--bordeaux-dark)', lineHeight: 1.2 }}
        >
          Ta vibe 💃
        </h1>
        <p
          className="font-body"
          style={{ color: '#8B3A3A', fontSize: '16px', marginTop: '8px', fontStyle: 'italic' }}
        >
          Pour qu&apos;on te matche avec les bonnes personnes
        </p>
      </div>

      <div style={{ marginBottom: '28px' }}>
        <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '14px', fontWeight: 500, color: 'var(--bordeaux-dark)', marginBottom: '12px' }}>
          Comment tu te décrirais ?
        </p>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
          {vibes.map((vibe) => (
            <button
              key={vibe}
              className={`chip ${form.vibe === vibe ? 'selected' : ''}`}
              onClick={() => setForm({ ...form, vibe })}
            >
              {vibe}
            </button>
          ))}
        </div>
      </div>

      <div style={{ marginBottom: '28px' }}>
        <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '14px', fontWeight: 500, color: 'var(--bordeaux-dark)', marginBottom: '12px' }}>
          À quelle fréquence tu voudrais participer ?
        </p>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
          {frequences.map((freq) => (
            <button
              key={freq}
              className={`chip ${form.frequence === freq ? 'selected' : ''}`}
              onClick={() => setForm({ ...form, frequence: freq })}
            >
              {freq}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label style={{ display: 'block', fontSize: '13px', fontWeight: 500, color: 'var(--bordeaux-dark)', marginBottom: '8px' }}>
          Un mot sur toi ? (optionnel)
        </label>
        <textarea
          className="input-base"
          style={{ resize: 'none', minHeight: '100px' }}
          placeholder="Ce qui t'a donné envie de rejoindre Pause Copines..."
          value={form.message}
          onChange={(e) => setForm({ ...form, message: e.target.value })}
        />
      </div>
    </div>
  );
}

function StepRecap({ form }: { form: any }) {
  return (
    <div>
      <div style={{ marginBottom: '32px' }}>
        <h1
          className="font-display"
          style={{ fontSize: '32px', fontWeight: 700, color: 'var(--bordeaux-dark)', lineHeight: 1.2 }}
        >
          Tout est bon ? 🌸
        </h1>
        <p
          className="font-body"
          style={{ color: '#8B3A3A', fontSize: '16px', marginTop: '8px', fontStyle: 'italic' }}
        >
          Vérifie tes infos avant d&apos;envoyer
        </p>
      </div>

      <div className="card">
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          <Row label="Prénom" value={form.prenom} />
          <Row label="Email" value={form.email} />
          {form.instagram && <Row label="Instagram" value={`@${form.instagram}`} />}
          <Row label="Âge" value={`${form.age} ans`} />
          {form.quartier && <Row label="Quartier" value={form.quartier} />}
          <div style={{ borderTop: '1px solid var(--rose-medium)', paddingTop: '14px' }}>
            <span style={{ fontSize: '12px', fontWeight: 500, color: '#c9a0a0', fontFamily: 'DM Sans', textTransform: 'uppercase', letterSpacing: '0.1em' }}>
              Passions
            </span>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginTop: '8px' }}>
              {form.interets.map((i: string) => (
                <span
                  key={i}
                  style={{
                    fontSize: '12px',
                    background: 'var(--rose-blush)',
                    border: '1px solid var(--rose-medium)',
                    borderRadius: '20px',
                    padding: '4px 10px',
                    color: 'var(--bordeaux)',
                    fontFamily: 'DM Sans',
                  }}
                >
                  {i}
                </span>
              ))}
            </div>
          </div>
          {form.vibe && <Row label="Vibe" value={form.vibe} />}
          {form.frequence && <Row label="Fréquence" value={form.frequence} />}
        </div>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '12px' }}>
      <span style={{ fontSize: '12px', fontWeight: 500, color: '#c9a0a0', fontFamily: 'DM Sans', textTransform: 'uppercase', letterSpacing: '0.1em', flexShrink: 0 }}>
        {label}
      </span>
      <span style={{ fontSize: '14px', color: 'var(--bordeaux-dark)', fontFamily: 'DM Sans', textAlign: 'right' }}>
        {value}
      </span>
    </div>
  );
}

function SuccessPage({ prenom }: { prenom: string }) {
  return (
    <div
      style={{
        minHeight: '100dvh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'var(--rose-blush)',
        padding: '32px 24px',
        textAlign: 'center',
      }}
    >
      <div style={{ animation: 'fadeUp 0.6s cubic-bezier(0.23, 1, 0.32, 1) forwards' }}>
        <div style={{ fontSize: '80px', marginBottom: '24px', animation: 'float 4s ease-in-out infinite' }}>
          🌸
        </div>
        <h1
          className="font-display"
          style={{ fontSize: '42px', fontWeight: 900, color: 'var(--bordeaux-dark)', lineHeight: 1.1 }}
        >
          Bienvenue {prenom} !
        </h1>
        <p
          className="font-script"
          style={{ fontSize: '28px', color: 'var(--bordeaux)', marginTop: '8px' }}
        >
          Tu fais partie de l&apos;aventure 💕
        </p>
        <p
          className="font-body"
          style={{
            fontSize: '17px',
            color: '#8B3A3A',
            marginTop: '20px',
            maxWidth: '380px',
            lineHeight: 1.7,
            fontStyle: 'italic',
          }}
        >
          On t&apos;enverra bientôt une invitation pour le prochain événement.
          Garde un œil sur ta boîte mail 👀
        </p>
        <Link href="/">
          <button
            className="btn-primary"
            style={{ marginTop: '32px', padding: '16px 40px', fontSize: '16px' }}
          >
            Retour à l&apos;accueil →
          </button>
        </Link>
      </div>
    </div>
  );
}
