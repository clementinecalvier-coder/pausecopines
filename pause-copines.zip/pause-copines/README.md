# 🌸 Pause Copines — PWA

Application web progressive pour la communauté **Pause Copines** — des événements pour les femmes parisiennes de 25-35 ans qui veulent créer de nouvelles connexions.

## Stack

- **Next.js 14** + TypeScript
- **Tailwind CSS** + CSS custom properties
- **Framer Motion** pour les animations
- **Vercel KV** pour la base de données (Redis)
- **PWA** avec next-pwa

---

## 🚀 Déploiement sur GitHub + Vercel

### 1. Créer le repo GitHub

```bash
git init
git add .
git commit -m "✨ Initial commit — Pause Copines PWA"
git branch -M main
git remote add origin https://github.com/TON_USERNAME/pause-copines.git
git push -u origin main
```

### 2. Connecter à Vercel

1. Va sur [vercel.com](https://vercel.com) et connecte ton compte GitHub
2. Clique **"Add New Project"** → importe `pause-copines`
3. Framework: **Next.js** (auto-détecté)
4. Clique **Deploy** 🎉

### 3. Configurer Vercel KV (base de données)

1. Dans ton projet Vercel → onglet **Storage**
2. Clique **Create Database** → choisis **KV**
3. Nomme-la `pause-copines-db` → **Create**
4. Les variables d'env `KV_REST_API_URL` et `KV_REST_API_TOKEN` sont auto-ajoutées

### 4. Variables d'environnement

Dans Vercel → Settings → Environment Variables, ajoute :

| Variable | Valeur |
|----------|--------|
| `ADMIN_SECRET` | un mot de passe fort |
| `NEXT_PUBLIC_ADMIN_PASSWORD` | même mot de passe |

> ⚠️ Change le mot de passe par défaut `pausecopines2025` avant de mettre en prod !

---

## 📱 Pages

| Page | URL | Description |
|------|-----|-------------|
| Landing | `/` | Page d'accueil avec events |
| Inscription | `/inscription` | Formulaire 5 étapes |
| Admin | `/admin` | Dashboard protégé par mot de passe |

---

## 🎨 Design

- **Palette** : Rose poudré `#fdf0f0` + Bordeaux `#b91c1c`
- **Typographies** : Playfair Display (display) + Dancing Script (script) + Cormorant Garamond (body) + DM Sans (UI)
- **Animations** : `ease-out` cubic-bezier, durées < 300ms, stagger delays, float effect

---

## 💻 Développement local

```bash
npm install
cp .env.example .env.local
npm run dev
```

Ouvre [http://localhost:3000](http://localhost:3000)

---

## 📂 Structure

```
src/
  pages/
    index.tsx          # Landing page
    inscription.tsx    # Formulaire d'inscription (5 steps)
    admin.tsx          # Dashboard admin
    api/
      inscription.ts   # POST → sauvegarde l'inscription
      admin/
        members.ts     # GET → liste des membres (protégé)
  styles/
    globals.css        # Design tokens, animations, composants
```

---

Fait avec 💕 pour Pause Copines
