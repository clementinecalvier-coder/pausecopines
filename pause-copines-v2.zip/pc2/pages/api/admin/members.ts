import type { NextApiRequest, NextApiResponse } from 'next'
import { store } from '../inscription'

const TOKEN = process.env.ADMIN_SECRET || 'pausecopines2025'

const MOCK = [
  { id:'1', prenom:'Sofia', email:'sofia@example.com', instagram:'sofia.paris', age:'28', quartier:'Le Marais',
    interets:['🍷 Vins & cocktails','🎨 Art & créativité','📚 Livres & culture'],
    envies:['💬 Des conversations profondes'], vibe:'🌸 Douce & bienveillante',
    frequence:'2-3 fois par mois', message:"J'adore l'idée de rencontrer des femmes qui me ressemblent !",
    createdAt: new Date(Date.now()-2*864e5).toISOString() },
  { id:'2', prenom:'Jade', email:'jade@example.com', instagram:'', age:'31', quartier:'Bastille',
    interets:['🎵 Musique & concerts','✈️ Voyages','🎭 Théâtre & spectacles'],
    envies:['🎉 Des nouvelles aventures'], vibe:'⚡ Spontanée & aventurière',
    frequence:'1 fois par semaine', message:'',
    createdAt: new Date(Date.now()-5*864e5).toISOString() },
  { id:'3', prenom:'Luna', email:'luna@example.com', instagram:'luna_copines', age:'26', quartier:'Montmartre',
    interets:['🌿 Nature & outdoor','🧘 Bien-être & yoga','🍽️ Gastronomie'],
    envies:['☕ Des rencontres régulières'], vibe:'🌊 Zen & équilibrée',
    frequence:'1 fois par mois', message:'',
    createdAt: new Date(Date.now()-10*864e5).toISOString() },
]

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') return res.status(405).end()

  const auth = req.headers.authorization
  if (!auth || auth !== `Bearer ${TOKEN}`) return res.status(401).json({ error: 'Non autorisé' })

  try {
    if (process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN) {
      const { kv } = await import('@vercel/kv')
      const ids: string[] = (await kv.get('list')) || []
      const members = await Promise.all(ids.map(async id => {
        const raw = await kv.get<string>(id)
        return raw ? JSON.parse(raw as string) : null
      }))
      return res.status(200).json({ members: members.filter(Boolean).reverse() })
    }
    const all = [...MOCK, ...store]
    return res.status(200).json({ members: all.sort((a,b)=>new Date(b.createdAt).getTime()-new Date(a.createdAt).getTime()) })
  } catch {
    return res.status(200).json({ members: MOCK })
  }
}
