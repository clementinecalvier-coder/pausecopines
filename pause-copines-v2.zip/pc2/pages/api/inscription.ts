import type { NextApiRequest, NextApiResponse } from 'next'

// In-memory fallback (dev only — use Vercel KV in prod)
const store: any[] = []

export { store }

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()

  const { email, prenom } = req.body
  if (!email || !prenom) return res.status(400).json({ error: 'Champs manquants' })

  const entry = { ...req.body, id: `m-${Date.now()}` }

  try {
    if (process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN) {
      const { kv } = await import('@vercel/kv')
      await kv.set(entry.id, JSON.stringify(entry))
      const list: string[] = (await kv.get('list')) || []
      await kv.set('list', [...list, entry.id])
    } else {
      store.push(entry)
    }
    return res.status(200).json({ ok: true })
  } catch (e) {
    store.push(entry)
    return res.status(200).json({ ok: true })
  }
}
