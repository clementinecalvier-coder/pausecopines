import { useState, useEffect } from 'react'
import Link from 'next/link'

type Member = {
  id:string; prenom:string; email:string; instagram?:string; age:string;
  quartier?:string; interets:string[]; envies:string[]; vibe:string;
  frequence:string; message?:string; createdAt:string;
}

const ADMIN_PWD = process.env.NEXT_PUBLIC_ADMIN_PASSWORD || 'pausecopines2025'

export default function Admin() {
  const [authed, setAuthed] = useState(false)
  const [pw, setPw] = useState('')
  const [err, setErr] = useState(false)
  const [members, setMembers] = useState<Member[]>([])
  const [loading, setLoading] = useState(false)
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState<Member|null>(null)

  const login = () => {
    if (pw === ADMIN_PWD) { setAuthed(true); setErr(false); load() }
    else { setErr(true); setPw('') }
  }

  const load = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/members', {
        headers: { Authorization: `Bearer ${ADMIN_PWD}` }
      })
      if (res.ok) { const d = await res.json(); setMembers(d.members || []) }
    } catch {}
    finally { setLoading(false) }
  }

  const filtered = members.filter(m =>
    [m.prenom,m.email,m.quartier].some(v=>v?.toLowerCase().includes(search.toLowerCase()))
  )

  if (!authed) return (
    <div style={{ minHeight:'100vh', background:'var(--blush)', display:'flex',
      alignItems:'center', justifyContent:'center', padding:24 }}>
      <div className="card" style={{ width:'100%', maxWidth:380, textAlign:'center',
        animation:'fadeUp 0.5s var(--ease) both' }}>
        <div style={{ fontSize:44, marginBottom:12 }}>🔐</div>
        <h1 className="fd" style={{ fontSize:28, fontWeight:700, color:'var(--bxd)', marginBottom:4 }}>Admin</h1>
        <p className="fs" style={{ color:'var(--bx)', fontSize:24, marginBottom:22 }}>Pause Copines.</p>
        <input className="input" type="password" placeholder="Mot de passe admin"
          value={pw} onChange={e=>setPw(e.target.value)}
          onKeyDown={e=>e.key==='Enter'&&login()}
          style={{ marginBottom:8 }} />
        {err && <p style={{ fontSize:12, color:'var(--bxl)', marginBottom:8 }}>Mot de passe incorrect</p>}
        <button className="btn" style={{ width:'100%', padding:'13px 0', fontSize:14 }} onClick={login}>
          Accéder →
        </button>
        <Link href="/"><span style={{ display:'block', marginTop:14, fontSize:12, color:'#d4a0a0', cursor:'pointer', textDecoration:'underline' }}>← Retour au site</span></Link>
      </div>
    </div>
  )

  return (
    <div style={{ minHeight:'100vh', background:'#f8f0f0' }}>
      {/* Admin nav */}
      <div style={{ background:'var(--bxd)', padding:'14px 24px',
        display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <span className="fd" style={{ color:'white', fontWeight:900, fontSize:18 }}>PAUSE</span>
          <span className="fs" style={{ color:'rgba(255,255,255,0.75)', fontSize:22 }}>Copines.</span>
          <span style={{ background:'rgba(255,255,255,0.15)', color:'white', fontSize:10,
            padding:'2px 10px', borderRadius:20, letterSpacing:'0.12em', textTransform:'uppercase' }}>Admin</span>
        </div>
        <button onClick={()=>setAuthed(false)} style={{ background:'rgba(255,255,255,0.12)',
          border:'none', color:'white', padding:'7px 16px', borderRadius:20, fontSize:12, cursor:'pointer' }}>
          Déconnexion
        </button>
      </div>

      <div style={{ padding:20, maxWidth:1000, margin:'0 auto' }}>
        {/* Stats */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(140px,1fr))', gap:12, marginBottom:20 }}>
          {[
            { l:'Membres total', v:members.length, e:'👥' },
            { l:'Cette semaine', e:'📈', v:members.filter(m=>{
              const d=new Date(m.createdAt); return (Date.now()-d.getTime())<7*864e5
            }).length },
            { l:'Avec Instagram', e:'📸', v:members.filter(m=>m.instagram).length },
          ].map(s=>(
            <div key={s.l} className="card" style={{ padding:'16px', textAlign:'center' }}>
              <div style={{ fontSize:24 }}>{s.e}</div>
              <div className="fd" style={{ fontSize:30, fontWeight:900, color:'var(--bx)', lineHeight:1 }}>{s.v}</div>
              <div style={{ fontSize:11, color:'#d4a0a0', marginTop:4 }}>{s.l}</div>
            </div>
          ))}
        </div>

        {/* Search */}
        <input className="input" style={{ maxWidth:380, marginBottom:14 }}
          placeholder="Rechercher par prénom, email, quartier..."
          value={search} onChange={e=>setSearch(e.target.value)} />

        {/* Table */}
        {loading
          ? <p style={{ textAlign:'center', padding:48, color:'#d4a0a0', fontStyle:'italic' }}>Chargement... 💕</p>
          : <div className="card" style={{ padding:0, overflow:'hidden' }}>
              <div style={{ overflowX:'auto' }}>
                <table style={{ width:'100%', borderCollapse:'collapse' }}>
                  <thead>
                    <tr style={{ background:'var(--blush)', borderBottom:'1px solid var(--rose-med)' }}>
                      {['Prénom','Email','Instagram','Âge','Quartier','Vibe','Date',''].map(h=>(
                        <th key={h} style={{ padding:'12px 14px', textAlign:'left', fontSize:10,
                          fontWeight:600, color:'#d4a0a0', textTransform:'uppercase', letterSpacing:'0.1em', whiteSpace:'nowrap' }}>
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.length===0
                      ? <tr><td colSpan={8} style={{ textAlign:'center', padding:40, color:'#d4a0a0', fontStyle:'italic' }}>Aucun membre pour l&apos;instant…</td></tr>
                      : filtered.map((m,i)=>(
                        <tr key={m.id||i}
                          style={{ borderBottom:'1px solid rgba(245,198,198,0.25)', cursor:'pointer',
                            transition:'background 130ms ease' }}
                          onMouseEnter={e=>(e.currentTarget.style.background='var(--blush)')}
                          onMouseLeave={e=>(e.currentTarget.style.background='transparent')}
                          onClick={()=>setSelected(m)}>
                          {[m.prenom, m.email, m.instagram?`@${m.instagram}`:'—', m.age,
                            m.quartier||'—', m.vibe||'—',
                            new Date(m.createdAt).toLocaleDateString('fr-FR')
                          ].map((v,j)=>(
                            <td key={j} style={{ padding:'12px 14px', fontSize:13, whiteSpace:'nowrap',
                              color: j===1 ? 'var(--bx)' : j===6 ? '#d4a0a0' : 'var(--bxd)' }}>{v}</td>
                          ))}
                          <td style={{ padding:'12px 14px' }}>
                            <button onClick={e=>{e.stopPropagation();setSelected(m)}}
                              style={{ fontSize:12, padding:'4px 12px', borderRadius:20,
                                border:'1px solid var(--bx)', background:'transparent',
                                color:'var(--bx)', cursor:'pointer', fontFamily:'DM Sans,sans-serif' }}>
                              Voir
                            </button>
                          </td>
                        </tr>
                      ))
                    }
                  </tbody>
                </table>
              </div>
            </div>
        }
        <p style={{ fontSize:11, color:'#d4a0a0', marginTop:10, fontStyle:'italic' }}>
          💡 Configure KV_REST_API_URL et KV_REST_API_TOKEN dans les variables Vercel pour persister les données.
        </p>
      </div>

      {/* Modal */}
      {selected && (
        <div onClick={()=>setSelected(null)} style={{
          position:'fixed', inset:0, background:'rgba(127,29,29,0.25)',
          backdropFilter:'blur(6px)', display:'flex', alignItems:'flex-end',
          justifyContent:'center', zIndex:100, padding:20 }}>
          <div onClick={e=>e.stopPropagation()} className="card"
            style={{ width:'100%', maxWidth:520, maxHeight:'80vh', overflowY:'auto',
              animation:'fadeUp 0.3s cubic-bezier(0.32,0.72,0,1) both' }}>
            <div style={{ display:'flex', justifyContent:'space-between', marginBottom:18 }}>
              <div>
                <h2 className="fd" style={{ fontSize:24, fontWeight:700, color:'var(--bxd)' }}>{selected.prenom}</h2>
                <p style={{ fontSize:12, color:'#d4a0a0' }}>{new Date(selected.createdAt).toLocaleDateString('fr-FR',{day:'numeric',month:'long',year:'numeric'})}</p>
              </div>
              <button onClick={()=>setSelected(null)} style={{ background:'var(--rose-light)', border:'none',
                borderRadius:'50%', width:34, height:34, cursor:'pointer', fontSize:14 }}>✕</button>
            </div>
            <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
              {[
                ['Email', selected.email],
                selected.instagram && ['Instagram', `@${selected.instagram}`],
                ['Âge', `${selected.age} ans`],
                selected.quartier && ['Quartier', selected.quartier],
                selected.vibe && ['Vibe', selected.vibe],
                selected.frequence && ['Fréquence', selected.frequence],
              ].filter(Boolean).map((r:any,i)=>(
                <div key={i} style={{ display:'flex', justifyContent:'space-between', padding:'7px 0',
                  borderBottom:'1px solid rgba(245,198,198,0.3)' }}>
                  <span style={{ fontSize:11, color:'#d4a0a0', textTransform:'uppercase', letterSpacing:'0.1em', fontWeight:500 }}>{r[0]}</span>
                  <span style={{ fontSize:13, color:'var(--bxd)' }}>{r[1]}</span>
                </div>
              ))}
              {selected.interets?.length > 0 && (
                <div style={{ paddingTop:8 }}>
                  <p style={{ fontSize:11, color:'#d4a0a0', textTransform:'uppercase', letterSpacing:'0.1em', fontWeight:500, marginBottom:8 }}>Centres d&apos;intérêt</p>
                  <div>{selected.interets.map(i=>(
                    <span key={i} style={{ display:'inline-block', margin:2, padding:'3px 10px', borderRadius:20,
                      fontSize:11, background:'var(--blush)', border:'1px solid var(--rose-med)', color:'var(--bx)' }}>{i}</span>
                  ))}</div>
                </div>
              )}
              {selected.message && (
                <div style={{ background:'var(--blush)', borderRadius:12, padding:14, marginTop:4 }}>
                  <p style={{ fontSize:11, color:'#d4a0a0', textTransform:'uppercase', letterSpacing:'0.1em', fontWeight:500, marginBottom:6 }}>Message</p>
                  <p style={{ fontFamily:'Playfair Display,serif', fontStyle:'italic', fontSize:14, color:'#8B3A3A', lineHeight:1.6 }}>
                    &ldquo;{selected.message}&rdquo;
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
