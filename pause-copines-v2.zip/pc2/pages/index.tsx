import { useEffect, useState } from 'react'
import Link from 'next/link'

const EVENTS = [
  { e: '🍷', title: 'Wine & Vibes',       desc: 'Dégustation vins naturels + rencontres', date: 'Sam 3 mai · 19h',    lieu: 'Oberkampf',       spots: 12 },
  { e: '🎨', title: 'Atelier Céramique',   desc: 'Crée ton bol en argile entre copines',  date: 'Dim 11 mai · 14h',   lieu: 'Le Marais',       spots: 8  },
  { e: '🧘', title: 'Yoga & Brunch',       desc: 'Yoga doux + brunch healthy ensoleillé', date: 'Sam 17 mai · 10h',   lieu: 'Canal St-Martin', spots: 15 },
  { e: '📚', title: 'Book Club Féministe', desc: 'Discussion autour d\'un livre fort',     date: 'Jeu 22 mai · 19h30', lieu: 'Montmartre',      spots: 10 },
  { e: '🎭', title: 'Impro & Cocktails',   desc: 'Cours d\'impro débutant + afterwork',   date: 'Ven 30 mai · 18h',   lieu: 'Bastille',        spots: 20 },
  { e: '🌿', title: 'Pique-nique Bota',    desc: 'Pique-nique au Jardin des Plantes',     date: 'Dim 8 juin · 13h',   lieu: '5ème',            spots: 25 },
]

export default function Home() {
  const [ready, setReady] = useState(false)
  useEffect(() => { setReady(true) }, [])

  return (
    <div style={{ minHeight: '100vh', background: 'var(--blush)' }}>

      {/* NAV */}
      <nav style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 50,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '16px 28px',
        background: 'rgba(253,240,240,0.88)',
        backdropFilter: 'blur(16px)',
        borderBottom: '1px solid rgba(245,198,198,0.3)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <span className="fd" style={{ color: 'var(--bx)', fontSize: 20, fontWeight: 900 }}>PAUSE</span>
          <span className="fs" style={{ color: 'var(--bx)', fontSize: 24, lineHeight: 1 }}>Copines.</span>
        </div>
        <Link href="/inscription">
          <span className="btn" style={{ padding: '10px 22px', fontSize: 13 }}>Rejoindre ✨</span>
        </Link>
      </nav>

      {/* HERO */}
      <section style={{
        minHeight: '100vh', display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
        textAlign: 'center', padding: '120px 24px 60px',
        position: 'relative', overflow: 'hidden',
      }}>
        {/* blobs */}
        <div style={{ position:'absolute', top:'-5%', right:'-8%', width:320, height:320,
          borderRadius:'60% 40% 70% 30% / 50% 60% 40% 50%',
          background:'rgba(245,198,198,0.4)', filter:'blur(40px)',
          animation:'float 8s ease-in-out infinite', pointerEvents:'none' }} />
        <div style={{ position:'absolute', bottom:'5%', left:'-8%', width:250, height:250,
          borderRadius:'40% 60% 30% 70% / 60% 40% 60% 40%',
          background:'rgba(229,62,62,0.07)', filter:'blur(50px)',
          animation:'float 11s ease-in-out infinite reverse', pointerEvents:'none' }} />

        {ready && <>
          <p className={`fade-up d1`} style={{ fontSize:11, letterSpacing:'0.2em', textTransform:'uppercase', color:'var(--bxl)', fontWeight:500 }}>
            Paris · 25–35 ans
          </p>
          <h1 className={`fd fade-up d2`} style={{ fontSize:'clamp(48px,10vw,88px)', fontWeight:900, color:'var(--bxd)', lineHeight:1.05, marginTop:12 }}>
            Trouve tes<br/>
            <em style={{ color:'var(--bx)', fontStyle:'italic' }}>nouvelles</em><br/>
            copines 💕
          </h1>
          <p className={`fade-up d3`} style={{
            fontFamily:'Playfair Display, serif', fontStyle:'italic', fontWeight:300,
            fontSize:'clamp(16px,3vw,21px)', color:'#8B3A3A',
            maxWidth:480, lineHeight:1.7, marginTop:20,
          }}>
            Des événements pensés pour les Parisiennes qui veulent sortir de leurs cercles habituels et créer de vraies connexions.
          </p>
          <div className={`fade-up d4`} style={{ display:'flex', gap:12, marginTop:32, flexWrap:'wrap', justifyContent:'center' }}>
            <Link href="/inscription"><span className="btn" style={{ fontSize:16, padding:'15px 38px' }}>Je m&apos;inscris 🌸</span></Link>
            <a href="#events"><span className="btn-outline" style={{ fontSize:16, padding:'15px 38px' }}>Voir les events ✨</span></a>
          </div>
          <div className={`fade-up d5`} style={{ display:'flex', alignItems:'center', gap:10, marginTop:36 }}>
            <div style={{ display:'flex' }}>
              {['#f8a4a4','#e07878','#c94040','#a02020'].map((c,i) => (
                <div key={i} style={{ width:34, height:34, borderRadius:'50%', background:c, border:'2px solid white',
                  marginLeft: i > 0 ? -10 : 0, display:'flex', alignItems:'center', justifyContent:'center', fontSize:14 }}>
                  {['😊','🌸','✨','💕'][i]}
                </div>
              ))}
            </div>
            <span style={{ fontFamily:'Playfair Display, serif', fontStyle:'italic', fontSize:14, color:'#8B3A3A' }}>
              +240 Parisiennes nous ont rejointes
            </span>
          </div>
        </>}
      </section>

      {/* EVENTS */}
      <section id="events" style={{ padding:'0 24px 80px' }}>
        <div style={{ maxWidth:900, margin:'0 auto' }}>
          <div style={{ textAlign:'center', marginBottom:40 }}>
            <h2 className="fd" style={{ fontSize:'clamp(34px,6vw,54px)', fontWeight:700, color:'var(--bxd)' }}>
              Les prochains<br/>
              <span className="fs" style={{ color:'var(--bx)', fontSize:'110%' }}>événements</span>
            </h2>
            <p style={{ fontFamily:'Playfair Display,serif', fontStyle:'italic', color:'#8B3A3A', marginTop:8, fontSize:16 }}>
              Petits groupes · Ambiance chaleureuse · Vraies rencontres
            </p>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(260px,1fr))', gap:18 }}>
            {EVENTS.map((ev, i) => <EventCard key={i} ev={ev} idx={i} />)}
          </div>
          <div style={{ textAlign:'center', marginTop:48 }}>
            <Link href="/inscription">
              <span className="btn" style={{ fontSize:16, padding:'17px 46px' }}>Rejoindre la communauté 🌸</span>
            </Link>
          </div>
        </div>
      </section>

      {/* WHY */}
      <section style={{ background:'white', borderTop:'1px solid rgba(245,198,198,0.4)', padding:'72px 24px' }}>
        <div style={{ maxWidth:680, margin:'0 auto', textAlign:'center' }}>
          <h2 className="fd" style={{ fontSize:'clamp(30px,5vw,46px)', fontWeight:700, color:'var(--bxd)' }}>
            Pourquoi <span className="fs" style={{ color:'var(--bx)', fontSize:'110%' }}>Pause Copines ?</span>
          </h2>
          <p style={{ fontFamily:'Playfair Display,serif', fontStyle:'italic', fontWeight:300,
            fontSize:17, lineHeight:1.8, color:'#8B3A3A', marginTop:16 }}>
            Parce qu&apos;après 25 ans à Paris, se faire de vraies copines devient un peu plus compliqué.
            On sort des études, les cercles se ferment… mais l&apos;envie de rencontres authentiques reste bien là.
          </p>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(180px,1fr))', gap:20, marginTop:40 }}>
            {[
              { icon:'🎯', title:'Ciblé',      desc:'Des femmes qui te ressemblent, même tranche d\'âge, mêmes envies' },
              { icon:'✨', title:'Qualitatif', desc:'Petits groupes pour de vraies conversations, pas du networking' },
              { icon:'🌸', title:'Safe',       desc:'Un espace bienveillant et sans prise de tête' },
            ].map((it, i) => (
              <div key={i} style={{ background:'var(--blush)', borderRadius:18, padding:'22px 16px',
                border:'1px solid rgba(245,198,198,0.4)' }}>
                <div style={{ fontSize:30, marginBottom:10 }}>{it.icon}</div>
                <div className="fd" style={{ fontSize:17, fontWeight:700, color:'var(--bxd)', marginBottom:8 }}>{it.title}</div>
                <div style={{ fontSize:13, color:'#8B3A3A', lineHeight:1.6 }}>{it.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ textAlign:'center', padding:'36px 24px', borderTop:'1px solid rgba(245,198,198,0.4)' }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'center', gap:4, marginBottom:8 }}>
          <span className="fd" style={{ color:'var(--bx)', fontWeight:900, fontSize:18 }}>PAUSE</span>
          <span className="fs" style={{ color:'var(--bx)', fontSize:22 }}>Copines.</span>
        </div>
        <p style={{ fontFamily:'Playfair Display,serif', fontStyle:'italic', color:'#d4a0a0', fontSize:13 }}>
          Paris · 2025 · Fait avec 💕
        </p>
      </footer>
    </div>
  )
}

function EventCard({ ev, idx }: { ev: typeof EVENTS[0]; idx: number }) {
  const [hov, setHov] = useState(false)
  return (
    <div
      className="card"
      style={{
        cursor:'pointer',
        transform: hov ? 'translateY(-4px)' : 'translateY(0)',
        boxShadow: hov ? '0 20px 48px rgba(185,28,28,0.13)' : '0 4px 24px rgba(185,28,28,0.06)',
        transition:'transform 240ms var(--ease), box-shadow 240ms var(--ease)',
        animation:`fadeUp 0.55s var(--ease) ${idx * 70}ms both`,
      }}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
    >
      <div style={{ fontSize:34, marginBottom:10 }}>{ev.e}</div>
      <h3 className="fd" style={{ fontSize:19, fontWeight:700, color:'var(--bxd)', marginBottom:6 }}>{ev.title}</h3>
      <p style={{ fontFamily:'Playfair Display,serif', fontStyle:'italic', fontWeight:300,
        fontSize:13, color:'#8B3A3A', lineHeight:1.5, marginBottom:14 }}>{ev.desc}</p>
      <div style={{ display:'flex', flexDirection:'column', gap:5, marginBottom:14 }}>
        <span style={{ fontSize:12, color:'var(--bx)', fontWeight:500 }}>📅 {ev.date}</span>
        <span style={{ fontSize:12, color:'var(--bx)', fontWeight:500 }}>📍 {ev.lieu}</span>
        <span style={{ fontSize:12, color:'#d4a0a0' }}>{ev.spots} places disponibles</span>
      </div>
      <Link href="/inscription">
        <span className="btn" style={{ display:'block', textAlign:'center', padding:'11px 0', fontSize:13 }}>
          Je veux y aller →
        </span>
      </Link>
    </div>
  )
}
