import { useState } from 'react'
import Link from 'next/link'

const INTERETS = [
  '🍷 Vins & cocktails','🎨 Art & créativité','🧘 Bien-être & yoga',
  '📚 Livres & culture','🎭 Théâtre & spectacles','🍽️ Gastronomie',
  '🎵 Musique & concerts','🌿 Nature & outdoor','🎬 Cinéma',
  '💄 Mode & beauté','🏃 Sport & fitness','✈️ Voyages',
  '🌱 Écologie','💡 Entrepreneuriat',
]
const ENVIES = [
  '💬 Des conversations profondes','🥂 Des sorties fun et légères',
  '🤝 Un réseau de femmes inspirantes','🎉 Des nouvelles aventures',
  '☕ Des rencontres régulières','🌍 Découvrir Paris autrement',
]
const VIBES = [
  '🌸 Douce & bienveillante','🔥 Intense & passionnée',
  '😄 Humor & légèreté','🎯 Ambitieuse & focus',
  '🌊 Zen & équilibrée','⚡ Spontanée & aventurière',
]
const FREQS = ['1 fois par mois','2-3 fois par mois','1 fois par semaine','Quand l\'inspiration vient !']

type F = {
  prenom:string; email:string; instagram:string; age:string; quartier:string;
  interets:string[]; envies:string[]; vibe:string; frequence:string; message:string;
}

export default function Inscription() {
  const [step, setStep] = useState(0)
  const [loading, setLoading] = useState(false)
  const [done, setDone] = useState(false)
  const [form, setForm] = useState<F>({
    prenom:'', email:'', instagram:'', age:'', quartier:'',
    interets:[], envies:[], vibe:'', frequence:'', message:'',
  })

  const toggle = (key: 'interets'|'envies', v: string) =>
    setForm(p => ({ ...p, [key]: p[key].includes(v) ? p[key].filter(x=>x!==v) : [...p[key], v] }))

  const ok = [
    form.prenom.trim() && form.email.trim() && form.age,
    form.interets.length >= 3,
    form.envies.length >= 1,
    form.vibe && form.frequence,
    true,
  ][step]

  const submit = async () => {
    setLoading(true)
    try {
      await fetch('/api/inscription', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ ...form, createdAt: new Date().toISOString() }),
      })
      setDone(true)
    } catch { setDone(true) }
    finally { setLoading(false) }
  }

  if (done) return (
    <div style={{ minHeight:'100vh', background:'var(--blush)', display:'flex',
      flexDirection:'column', alignItems:'center', justifyContent:'center',
      padding:32, textAlign:'center' }}>
      <div style={{ fontSize:72, marginBottom:20, animation:'float 4s ease-in-out infinite' }}>🌸</div>
      <h1 className="fd" style={{ fontSize:42, fontWeight:900, color:'var(--bxd)' }}>
        Bienvenue {form.prenom} !
      </h1>
      <p className="fs" style={{ fontSize:28, color:'var(--bx)', margin:'6px 0 14px' }}>
        Tu fais partie de l&apos;aventure 💕
      </p>
      <p style={{ fontFamily:'Playfair Display,serif', fontStyle:'italic', fontSize:16,
        color:'#8B3A3A', maxWidth:360, lineHeight:1.7, marginBottom:28 }}>
        On t&apos;enverra bientôt une invitation pour le prochain événement.
        Garde un œil sur ta boîte mail 👀
      </p>
      <Link href="/"><span className="btn" style={{ fontSize:16, padding:'15px 38px' }}>Retour à l&apos;accueil →</span></Link>
    </div>
  )

  return (
    <div style={{ minHeight:'100vh', background:'var(--blush)', display:'flex', flexDirection:'column' }}>

      {/* Header */}
      <div style={{ padding:'18px 24px', display:'flex', alignItems:'center', justifyContent:'space-between',
        background:'rgba(253,240,240,0.88)', backdropFilter:'blur(16px)',
        borderBottom:'1px solid rgba(245,198,198,0.3)', position:'sticky', top:0, zIndex:10 }}>
        <Link href="/">
          <span style={{ display:'flex', alignItems:'center', gap:4, cursor:'pointer' }}>
            <span className="fd" style={{ color:'var(--bx)', fontSize:18, fontWeight:900 }}>PAUSE</span>
            <span className="fs" style={{ color:'var(--bx)', fontSize:22 }}>Copines.</span>
          </span>
        </Link>
        <span style={{ fontSize:12, color:'#d4a0a0' }}>Étape {step+1} / 5</span>
      </div>

      {/* Progress */}
      <div style={{ height:3, background:'var(--rose-med)' }}>
        <div style={{ height:'100%', background:'var(--bx)', width:`${step/4*100}%`,
          transition:'width 360ms var(--ease)' }} />
      </div>

      {/* Dots */}
      <div style={{ display:'flex', justifyContent:'center', gap:8, padding:'14px 0' }}>
        {[0,1,2,3,4].map(i => (
          <div key={i} style={{ width:8, height:8, borderRadius:'50%', transition:'background 250ms ease',
            background: i===step ? 'var(--bx)' : i<step ? 'var(--bxl)' : 'var(--rose-med)' }} />
        ))}
      </div>

      {/* Body */}
      <div style={{ flex:1, maxWidth:540, width:'100%', margin:'0 auto', padding:'0 20px 40px' }}>

        <div key={step} style={{ animation:'fadeUp 0.38s var(--ease) both' }}>

          {/* STEP 0 */}
          {step===0 && <>
            <h2 className="fd" style={{ fontSize:30, fontWeight:700, color:'var(--bxd)', marginBottom:6 }}>Parle-nous de toi 🌸</h2>
            <p style={{ fontFamily:'Playfair Display,serif', fontStyle:'italic', color:'#8B3A3A', fontSize:15, marginBottom:24 }}>Ces infos restent entre nous, promis !</p>
            <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
              <div>
                <label>Ton prénom *</label>
                <input className="input" placeholder="Luna, Sofia, Jade..." value={form.prenom}
                  onChange={e=>setForm({...form,prenom:e.target.value})} />
              </div>
              <div>
                <label>Ton email *</label>
                <input className="input" type="email" placeholder="ton@email.fr" value={form.email}
                  onChange={e=>setForm({...form,email:e.target.value})} />
              </div>
              <div>
                <label>Instagram (facultatif)</label>
                <div style={{ position:'relative' }}>
                  <span style={{ position:'absolute', left:14, top:'50%', transform:'translateY(-50%)', color:'#d4a0a0', fontSize:14 }}>@</span>
                  <input className="input" style={{ paddingLeft:30 }} placeholder="tonpseudo" value={form.instagram}
                    onChange={e=>setForm({...form,instagram:e.target.value})} />
                </div>
              </div>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
                <div>
                  <label>Ton âge *</label>
                  <select className="input" value={form.age} onChange={e=>setForm({...form,age:e.target.value})}>
                    <option value="">Âge...</option>
                    {Array.from({length:11},(_,i)=>25+i).map(a=>(
                      <option key={a} value={a}>{a} ans</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label>Quartier</label>
                  <input className="input" placeholder="Marais, 10ème..." value={form.quartier}
                    onChange={e=>setForm({...form,quartier:e.target.value})} />
                </div>
              </div>
            </div>
          </>}

          {/* STEP 1 */}
          {step===1 && <>
            <h2 className="fd" style={{ fontSize:30, fontWeight:700, color:'var(--bxd)', marginBottom:6 }}>Tes passions 💫</h2>
            <p style={{ fontFamily:'Playfair Display,serif', fontStyle:'italic', color:'#8B3A3A', fontSize:15, marginBottom:20 }}>Choisis au moins 3 centres d&apos;intérêt</p>
            <div>{INTERETS.map(v=>(
              <button key={v} className={`chip${form.interets.includes(v)?' on':''}`}
                onClick={()=>toggle('interets',v)}>{v}</button>
            ))}</div>
            {form.interets.length > 0 && (
              <p style={{ marginTop:12, fontSize:13, color:'var(--bx)' }}>{form.interets.length} sélectionné(s) 💕</p>
            )}
          </>}

          {/* STEP 2 */}
          {step===2 && <>
            <h2 className="fd" style={{ fontSize:30, fontWeight:700, color:'var(--bxd)', marginBottom:6 }}>Ce que tu cherches ✨</h2>
            <p style={{ fontFamily:'Playfair Display,serif', fontStyle:'italic', color:'#8B3A3A', fontSize:15, marginBottom:20 }}>Qu&apos;est-ce qui t&apos;attire dans Pause Copines ?</p>
            <div>{ENVIES.map(v=>(
              <button key={v} className={`chip${form.envies.includes(v)?' on':''}`}
                onClick={()=>toggle('envies',v)}>{v}</button>
            ))}</div>
          </>}

          {/* STEP 3 */}
          {step===3 && <>
            <h2 className="fd" style={{ fontSize:30, fontWeight:700, color:'var(--bxd)', marginBottom:6 }}>Ta vibe 💃</h2>
            <p style={{ fontFamily:'Playfair Display,serif', fontStyle:'italic', color:'#8B3A3A', fontSize:15, marginBottom:20 }}>Pour qu&apos;on te matche avec les bonnes personnes</p>
            <p style={{ fontSize:13, fontWeight:500, color:'var(--bxd)', marginBottom:10 }}>Comment tu te décrirais ?</p>
            <div style={{ marginBottom:24 }}>{VIBES.map(v=>(
              <button key={v} className={`chip${form.vibe===v?' on':''}`}
                onClick={()=>setForm({...form,vibe:v})}>{v}</button>
            ))}</div>
            <p style={{ fontSize:13, fontWeight:500, color:'var(--bxd)', marginBottom:10 }}>À quelle fréquence tu voudrais participer ?</p>
            <div style={{ marginBottom:20 }}>{FREQS.map(v=>(
              <button key={v} className={`chip${form.frequence===v?' on':''}`}
                onClick={()=>setForm({...form,frequence:v})}>{v}</button>
            ))}</div>
            <label>Un mot sur toi ? (optionnel)</label>
            <textarea className="input" style={{ resize:'none', minHeight:90 }}
              placeholder="Ce qui t'a donné envie de rejoindre Pause Copines..."
              value={form.message} onChange={e=>setForm({...form,message:e.target.value})} />
          </>}

          {/* STEP 4 */}
          {step===4 && <>
            <h2 className="fd" style={{ fontSize:30, fontWeight:700, color:'var(--bxd)', marginBottom:6 }}>Tout est bon ? 🌸</h2>
            <p style={{ fontFamily:'Playfair Display,serif', fontStyle:'italic', color:'#8B3A3A', fontSize:15, marginBottom:20 }}>Vérifie avant d&apos;envoyer</p>
            <div className="card" style={{ padding:20 }}>
              {[
                ['Prénom', form.prenom],
                ['Email', form.email],
                form.instagram && ['Instagram', `@${form.instagram}`],
                ['Âge', form.age ? `${form.age} ans` : ''],
                form.quartier && ['Quartier', form.quartier],
                form.vibe && ['Vibe', form.vibe],
                form.frequence && ['Fréquence', form.frequence],
              ].filter(Boolean).map((row: any, i) => (
                <div key={i} style={{ display:'flex', justifyContent:'space-between',
                  padding:'8px 0', borderBottom: i>0 ? '1px solid rgba(245,198,198,0.3)' : 'none' }}>
                  <span style={{ fontSize:11, color:'#d4a0a0', textTransform:'uppercase', letterSpacing:'0.1em', fontWeight:500 }}>{row[0]}</span>
                  <span style={{ fontSize:13, color:'var(--bxd)' }}>{row[1]}</span>
                </div>
              ))}
              {form.interets.length > 0 && (
                <div style={{ paddingTop:12, marginTop:4 }}>
                  <p style={{ fontSize:11, color:'#d4a0a0', textTransform:'uppercase', letterSpacing:'0.1em', fontWeight:500, marginBottom:8 }}>Passions</p>
                  <div>{form.interets.map(i=>(
                    <span key={i} style={{ display:'inline-block', margin:2, padding:'3px 10px', borderRadius:20,
                      fontSize:11, background:'var(--blush)', border:'1px solid var(--rose-med)', color:'var(--bx)' }}>{i}</span>
                  ))}</div>
                </div>
              )}
            </div>
          </>}

        </div>

        {/* Nav buttons */}
        <div style={{ display:'flex', gap:10, marginTop:28 }}>
          {step > 0 && (
            <button className="btn-outline" style={{ flex:1, padding:'14px 0', fontSize:14 }}
              onClick={()=>setStep(s=>s-1)}>← Retour</button>
          )}
          {step < 4
            ? <button className="btn" style={{ flex:2, padding:'14px 0', fontSize:14, opacity:ok?1:0.45 }}
                onClick={()=>ok&&setStep(s=>s+1)} disabled={!ok}>Continuer →</button>
            : <button className="btn" style={{ flex:2, padding:'14px 0', fontSize:14 }}
                onClick={submit} disabled={loading}>
                {loading ? '💕 Envoi...' : "C'est parti ! 🌸"}
              </button>
          }
        </div>
      </div>
    </div>
  )
}
